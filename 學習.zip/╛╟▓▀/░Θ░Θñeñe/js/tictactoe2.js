const o = 'o';
const x = 'x';
let turn = 0; //even for player 'o', odd for player 'x'

function play(index){
   let button = document.querySelectorAll('#board button')[index];
   if(button.classList.contains('disable')){
       alert('Already filled.');
   }else if(turn%2==0){
       button.textContent = 'o';
       button.classList.add('o','disable') //由於您首先禁用它，因此啟用它的方法是將其disabled屬性設置為false。要在Javascript中更改其禁用的屬性，請使用以下命令：var btn = document.getElementById（“ Button ”）; BTN。disabled = false; 顯然要再次禁用它，你會使用true。
       turn++;
       if(checkWin('o')){
          alert('Winner: O');
          turn = 0;
       }
   }else if(turn%2==1){
       button.textContent = 'x';
       button.classList.add('x','disable');
       turn++;
       if(checkWin('x')){
         alert('Winner: X');
         turn = 0;
       }
   }
   if(turn==9) alert("Tie game.");
}

function checkWin2(player){
    let p = document.querySelectorAll('#board button');
    
    if(p[0].classList.contains(player) && p[1].classList.contains(player) && p[2].classList.contains(player) ||
       p[3].classList.contains(player) && p[4].classList.contains(player) && p[5].classList.contains(player) ||
       p[6].classList.contains(player) && p[7].classList.contains(player) && p[8].classList.contains(player) ||
       p[0].classList.contains(player) && p[3].classList.contains(player) && p[6].classList.contains(player) ||
       p[1].classList.contains(player) && p[4].classList.contains(player) && p[7].classList.contains(player) ||
       p[2].classList.contains(player) && p[5].classList.contains(player) && p[8].classList.contains(player) ||
       p[0].classList.contains(player) && p[4].classList.contains(player) && p[8].classList.contains(player) ||
       p[2].classList.contains(player) && p[4].classList.contains(player) && p[6].classList.contains(player)
    ) 
      return true;
    else 
      return false;
}

function checkWin(player){
    let p = document.querySelectorAll('#board button');
    let s = [];
    p.forEach(function(button){
       if(button.classList.contains(player))
         s.push(1);
       else
         s.push(0);
    })

    if(s[0] + s[1] + s[2] == 3 || s[3] + s[4] + s[5] == 3 || s[6] + s[7] + s[8] == 3 ||
       s[0] + s[3] + s[6] == 3 || s[1] + s[4] + s[7] == 3 || s[2] + s[5] + s[8] == 3 ||
       s[0] + s[4] + s[8] == 3 || s[2] + s[4] + s[6] == 3
    ) 
      return true;
    else 
      return false;
}

function reset(){
    let p = document.querySelectorAll('#board button');
    p.forEach(function(button){
      button.textContent = '+';
      button.classList.remove('o');
      button.classList.remove('x');
      button.classList.remove('disable');
       turn = 0;
    });
}
