function play(index) {
  let p;

  if (index >= 1 && index <= 5)
      p = document.getElementById("hplayer");  
  else
      p = document.getElementById("vplayer");
  
  switch (index) {
      case 1:
      case 6:
          p.innerHTML = '<img src="img/TKU1.png" />';
          break;

      case 2:
      case 7:
          p.innerHTML = '<img src="img/TKU2.png" />';
          break;

      case 3:
      case 8:
          p.innerHTML = '<img src="img/TKU3.png" />';
          break;

      case 4:
      case 9:
          p.innerHTML = '<img src="img/TKU4.png" />';
          break;

      case 5:
      case 10:
          p.innerHTML = '<img src="img/TKU5.png" />';
          break;
  }

}

function changeNav(pos) {
   let h;
   let v;
   let c;
    switch (pos) {
        case 1: // horizontal
            h = document.querySelector('#hNav');
            h.style.display = 'block';
            v = document.querySelector('#vNav');
            v.style.display = 'none';
            c = document.querySelector("#container");
            c.style.height = 500010;
            break;
        case 2: // vertical
            h = document.querySelector('#hNav');
            h.style.display = 'none';
            v = document.querySelector('#vNav');
            v.style.display = 'block';
            c = document.querySelector("#container");
            c.style.height = 400000;
            break;
    }
}