var a = '!';
console.log(a.length);